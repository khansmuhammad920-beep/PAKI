# PAKI — Android Music App

PAKI is an Android starter app for local audio and YouTube music playback.

## Included in this first build
- Purple/dark PAKI interface
- YouTube search in the app; selecting a result opens the official YouTube embedded player
- Pick and play local audio files with Android's document picker
- Voice search using the device speech-recognition service
- Media3 ExoPlayer for local audio playback
- GitHub Actions workflow to build a debug APK on pushes to `main`

## Build APK
1. Open the **Actions** tab in this repository.
2. Select **Build PAKI APK**.
3. Open the newest successful run.
4. In **Artifacts**, download **PAKI-debug-apk** and extract the ZIP.
5. Install `app-debug.apk` on your Android phone.

## Notes
- YouTube playback uses the official embedded player. The app does not download YouTube audio or video.
- Voice recognition depends on a speech-recognition service installed on the phone.
- This is the first functional starter build. Background playback service, favorites/playlists, and a custom Paki voice are not included yet.
