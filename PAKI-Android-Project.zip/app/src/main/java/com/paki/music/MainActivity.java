package com.paki.music;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO = 41, VOICE_INPUT = 42;
    private final int bg = Color.rgb(15, 9, 31), panel = Color.rgb(42, 24, 70);
    private final int purple = Color.rgb(190, 110, 255);
    private EditText searchBox;
    private WebView webView;
    private TextView status;
    private ExoPlayer player;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        player = new ExoPlayer.Builder(this).build();
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(15), dp(16), dp(15), dp(10));
        root.setBackgroundColor(bg);

        TextView logo = new TextView(this);
        logo.setText("♫  PAKI");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(32);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView tagline = new TextView(this);
        tagline.setText("YOUR MUSIC, YOUR VOICE");
        tagline.setTextColor(purple);
        tagline.setTextSize(11);
        tagline.setGravity(Gravity.CENTER);
        root.addView(tagline, new LinearLayout.LayoutParams(-1, dp(28)));

        LinearLayout searchRow = new LinearLayout(this);
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Search YouTube music...");
        searchBox.setHintTextColor(0xffc2b2d2);
        searchBox.setTextColor(Color.WHITE);
        searchBox.setTextSize(14);
        searchBox.setPadding(dp(10), 0, dp(8), 0);
        searchBox.setBackgroundColor(panel);
        searchRow.addView(searchBox, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button search = button("SEARCH");
        search.setOnClickListener(v -> searchYouTube());
        searchRow.addView(search, new LinearLayout.LayoutParams(dp(92), dp(48)));
        root.addView(searchRow);

        LinearLayout actions = new LinearLayout(this);
        Button voice = button("🎙 VOICE");
        voice.setOnClickListener(v -> startVoice());
        Button local = button("♫ LOCAL SONG");
        local.setOnClickListener(v -> chooseAudio());
        actions.addView(voice, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(local, new LinearLayout.LayoutParams(0, dp(46), 1));
        root.addView(actions);

        status = new TextView(this);
        status.setText("Ready • Search a song or choose music from your phone");
        status.setTextColor(0xffdfd2ee);
        status.setTextSize(12);
        status.setPadding(dp(4), dp(9), dp(4), dp(9));
        root.addView(status);

        webView = new WebView(this);
        webView.setBackgroundColor(bg);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String id = videoIdFrom(request.getUrl().toString());
                if (id != null) { playYouTube(id); return true; }
                return false;
            }
        });
        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(-1, 0, 1);
        webParams.topMargin = dp(5);
        root.addView(webView, webParams);

        TextView localTitle = new TextView(this);
        localTitle.setText("LOCAL MUSIC PLAYER");
        localTitle.setTextColor(purple);
        localTitle.setTextSize(11);
        localTitle.setGravity(Gravity.CENTER);
        localTitle.setPadding(0, dp(7), 0, dp(3));
        root.addView(localTitle);

        LinearLayout playback = new LinearLayout(this);
        Button play = button("▶  PLAY / RESUME");
        play.setOnClickListener(v -> { if (!player.isPlaying()) player.play(); else player.pause(); });
        Button pause = button("Ⅱ  PAUSE");
        pause.setOnClickListener(v -> player.pause());
        playback.addView(play, new LinearLayout.LayoutParams(0, dp(44), 1));
        playback.addView(pause, new LinearLayout.LayoutParams(0, dp(44), 1));
        root.addView(playback);
        setContentView(root);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        return b;
    }

    private void searchYouTube() {
        String q = searchBox.getText().toString().trim();
        if (q.isEmpty()) { searchBox.setError("Enter a song name"); return; }
        status.setText("YouTube results • Tap a video to open the embedded player");
        webView.loadUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q));
    }

    private void playYouTube(String id) {
        status.setText("Official YouTube embedded player");
        String html = "<!doctype html><html><body style='margin:0;background:#0f091f'>" +
            "<iframe width='100%' height='100%' src='https://www.youtube.com/embed/" + id +
            "?playsinline=1' title='YouTube player' frameborder='0' " +
            "allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share' allowfullscreen></iframe>" +
            "</body></html>";
        webView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null);
    }

    private String videoIdFrom(String url) {
        try {
            Uri u = Uri.parse(url);
            String host = u.getHost() == null ? "" : u.getHost();
            if (host.endsWith("youtu.be")) return u.getLastPathSegment();
            if (host.contains("youtube.com")) {
                if (url.contains("/embed/")) {
                    String[] parts = u.getPath().split("/");
                    return parts.length > 2 ? parts[parts.length - 1] : null;
                }
                return u.getQueryParameter("v");
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void chooseAudio() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("audio/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_AUDIO);
    }

    private void startVoice() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a song name");
            startActivityForResult(i, VOICE_INPUT);
        } catch (Exception e) {
            Toast.makeText(this, "Voice input is unavailable on this device", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == PICK_AUDIO) {
            Uri uri = data.getData();
            if (uri != null) {
                player.setMediaItem(MediaItem.fromUri(uri));
                player.prepare();
                player.play();
                status.setText("Playing local audio");
            }
        } else if (requestCode == VOICE_INPUT) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                searchBox.setText(results.get(0));
                searchYouTube();
            }
        }
    }

    private int dp(int n) { return (int) (n * getResources().getDisplayMetrics().density); }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        if (player != null) player.release();
        super.onDestroy();
    }
}
